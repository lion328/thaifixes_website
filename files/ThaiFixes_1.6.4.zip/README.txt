ThaiFixes LegacyMaker for Minecraft 1.6.4.
Copyright (C) 2013 Waritnan Sookbuntherng AKA. lion328.

Not compatible for some other modification like Optifine.
Thanks for Sayoui, He is a first contributor.
Thanks for using or modification.