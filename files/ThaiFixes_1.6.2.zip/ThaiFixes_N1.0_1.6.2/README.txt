ThaiFixes-N 1.0
=========================
Created by lion328.
Thanks Minecraft Coder Pack (MCP).
